## the language
 HTML
 CSS
 JS

## useing function
The Navigation
The dynamic active
The scrolling effect

## what happen in it
making navbar dynamic and responsive
